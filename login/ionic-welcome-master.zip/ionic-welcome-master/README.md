# ionic-welcome
Ionic Project with Welcome page. 


<table><tr>
<td width="25%">
Welcome page
<img src="http://i.imgur.com/tNmu7Ce.png" width="200" alt="Ionic 3 and Angular 4 Create Welcome page with Login and Logout">
</td>
<td width="25%">
Signup Page
<img src="http://i.imgur.com/bxShO36.png" width="200" alt="Ionic 3 and Angular 4 Create Welcome page with Login and Logout">
</td>
<td width="25%">
Home page
<img src="http://i.imgur.com/IZPEqiP.png" width="200" alt="Ionic 3 and Angular 4 Create Welcome page with Login and Logout">
</td>

</tr></table>

Install Node JS Software

Go to terminal or command line.

Execute following commands to run this application.


```
$ git clone https://github.com/srinivastamada/ionic-welcome.git
$ cd ionic-welcome
$ npm install
$ ionic serve

```

ios
```
$ cordova add platform ios

$ ionic build ios

```

Android
```
$ cordova add platform android

$ ionic build android

```

More Info Tutorial: <a href="http://www.9lessons.info/2017/06/ionic3-angular4-create-welcome-page.html">Ionic 3 and Angular 4:Create a Welcome Page with Login and Logout.</a>
