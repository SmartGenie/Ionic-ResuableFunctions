# Ionic-OCR
A simple app to show how to implement OCR with Ionic 3.x

## Install Ionic

> npm install -g cordova ionic

## Installation modules

> npm install

## Developing mode

> ionic serve

### Build

> ionic build

### Deploy in device

> ionic cordova run android